# CHRONO NEON
### DEVELOPED BY LEONARDO
> Cronômetro flutuante premium com efeitos neon — Android

---

## COMO GERAR O APK PELO GITHUB (SEM PC)

### PASSO 1 — Criar conta no GitHub
1. Abre o Chrome no celular
2. Acessa **https://github.com**
3. Toca em **Sign up**
4. Preenche email, senha e username
5. Confirma o email

---

### PASSO 2 — Criar o repositório
1. Loga no GitHub
2. Toca no **+** → **New repository**
3. Nome: `chrono-neon`
4. Marca **Public**
5. Marca **Add a README file**
6. Toca em **Create repository**

---

### PASSO 3 — Enviar os arquivos

Você precisa enviar cada arquivo do projeto para o repositório.

**Para cada arquivo:**
1. No repositório, toca em **Add file → Create new file**
2. No campo do nome, digita o caminho completo do arquivo
   - Exemplo: `app/src/main/AndroidManifest.xml`
3. Cola o conteúdo do arquivo
4. Toca em **Commit changes**

**Ordem de envio:**
```
1.  settings.gradle.kts
2.  build.gradle.kts
3.  gradle/wrapper/gradle-wrapper.properties
4.  gradle/libs.versions.toml (se existir)
5.  app/build.gradle.kts
6.  app/src/main/AndroidManifest.xml
7.  app/src/main/res/values/strings.xml
8.  app/src/main/res/values/themes.xml
9.  app/src/main/res/xml/file_paths.xml
10. app/src/main/java/com/chrononeon/app/engine/StopwatchEngine.kt
11. app/src/main/java/com/chrononeon/app/settings/SettingsRepository.kt
12. app/src/main/java/com/chrononeon/app/service/FloatingService.kt
13. app/src/main/java/com/chrononeon/app/ui/theme/Theme.kt
14. app/src/main/java/com/chrononeon/app/MainViewModel.kt
15. app/src/main/java/com/chrononeon/app/ui/screens/HomeScreen.kt
16. app/src/main/java/com/chrononeon/app/ui/screens/CustomizeScreen.kt
17. app/src/main/java/com/chrononeon/app/ui/screens/ConfigScreen.kt
18. app/src/main/java/com/chrononeon/app/MainActivity.kt
19. gradlew
20. .github/workflows/build.yml   ← MAIS IMPORTANTE
```

---

### PASSO 4 — Executar a compilação

1. No repositório, toca na aba **Actions**
2. Toca em **Build APK** no menu esquerdo
3. Toca em **Run workflow** → **Run workflow** (botão verde)
4. Aguarda o círculo amarelo virar ✅ verde (~5-10 minutos)

---

### PASSO 5 — Baixar o APK

1. Toca no workflow concluído ✅
2. Rola até **Artifacts**
3. Toca em **ChronoNeon-APK**
4. Baixa o ZIP
5. Extrai com **ZArchiver**
6. Instala o `app-debug.apk`

---

### SE DER ERRO

| Erro | Solução |
|---|---|
| `gradlew: Permission denied` | Verifica se o arquivo `gradlew` está na raiz |
| `Could not resolve` | Verifica o `app/build.gradle.kts` |
| `Manifest merger failed` | Verifica o `AndroidManifest.xml` |
| `Kotlin compilation error` | Vê qual arquivo .kt tem erro no log |

---

## FUNCIONALIDADES

- ✅ Cronômetro flutuante real (WindowManager)
- ✅ Funciona sobre outros apps (SYSTEM_ALERT_WINDOW)
- ✅ Funciona em segundo plano (Foreground Service)
- ✅ 1 toque = pausar/continuar
- ✅ 2 toques = zerar
- ✅ Arrastar para mover
- ✅ Personalização completa (cor, tamanho, transparência)
- ✅ 5 modelos de painel
- ✅ Salva posição e preferências
- ✅ Notificação com controles

## TECNOLOGIAS

- Kotlin
- Jetpack Compose
- Material 3
- Foreground Service
- WindowManager Overlay
- DataStore Preferences
- SystemClock.elapsedRealtime()

## COMPATIBILIDADE

- Android 8.0+ (API 26)
- Testado em ARM64

---

CHRONO NEON • DEVELOPED BY LEONARDO
