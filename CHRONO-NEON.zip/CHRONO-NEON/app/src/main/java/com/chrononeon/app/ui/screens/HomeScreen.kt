package com.chrononeon.app.ui.screens

import android.app.Activity
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.chrononeon.app.MainViewModel
import com.chrononeon.app.ui.theme.*

@Composable
fun HomeScreen(vm: MainViewModel) {
    val settings by vm.settings.collectAsState()
    var hasPermission by remember { mutableStateOf(vm.hasOverlayPermission()) }
    var serviceRunning by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { hasPermission = vm.hasOverlayPermission() }

    // Pulso animado
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1500, easing = EaseInOutSine), RepeatMode.Reverse
        ), label = "glow"
    )

    Box(Modifier.fillMaxSize().background(BgDeep)) {

        // Efeito de luz de fundo
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NeonBlue.copy(alpha = 0.08f * glow), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.3f),
                    radius = size.width * 0.7f
                )
            )
        }

        Column(
            Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(Modifier.height(40.dp))

            // Logo
            Text(
                "CHRONO NEON",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 6.sp,
                color = NeonBlue,
                textAlign = TextAlign.Center,
                style = LocalTextStyle.current.copy(
                    shadow = Shadow(NeonBlue.copy(alpha = glow), Offset(0f, 0f), 20f)
                )
            )
            Text(
                "DEVELOPED BY LEONARDO",
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                color = NeonCyan.copy(alpha = 0.7f),
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(8.dp))

            // Preview cronômetro
            NeonCard {
                Column(
                    Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("00:00:00", fontSize = 48.sp, fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold, color = Color.White,
                        style = LocalTextStyle.current.copy(
                            shadow = Shadow(NeonBlue.copy(alpha = 0.6f), Offset(0f,0f), 15f)
                        )
                    )
                    if (settings.showMillis)
                        Text(".00", fontSize = 24.sp, fontFamily = FontFamily.Monospace,
                            color = NeonBlue.copy(alpha = 0.8f))
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center) {
                        Box(Modifier.size(8.dp).background(
                            if (serviceRunning) NeonGreen else NeonBlue.copy(0.5f),
                            RoundedCornerShape(50)
                        ))
                        Spacer(Modifier.width(6.dp))
                        Text(if (serviceRunning) "ATIVO" else "PARADO",
                            fontSize = 11.sp, letterSpacing = 2.sp, color = NeonCyan)
                    }
                }
            }

            // Permissão
            if (!hasPermission) {
                NeonCard(borderColor = NeonRed) {
                    Column(Modifier.fillMaxWidth().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.Warning, null, tint = NeonRed, modifier = Modifier.size(28.dp))
                        Text("Permissão necessária", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("O cronômetro flutuante precisa da permissão\n\"Sobrepor a outros apps\"",
                            color = Color.White.copy(0.7f), textAlign = TextAlign.Center, fontSize = 13.sp)
                        Button(
                            onClick = { launcher.launch(vm.overlaySettingsIntent()) },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("ATIVAR PERMISSÃO", letterSpacing = 1.sp) }
                    }
                }
            }

            // Botão principal
            Button(
                onClick = {
                    if (hasPermission) {
                        if (!serviceRunning) { vm.startFloating(); serviceRunning = true }
                        else                 { vm.stopFloating();  serviceRunning = false }
                    } else {
                        launcher.launch(vm.overlaySettingsIntent())
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (serviceRunning) NeonPurple else NeonBlue
                )
            ) {
                Icon(if (serviceRunning) Icons.Default.Stop else Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (serviceRunning) "PARAR CRONÔMETRO" else "ATIVAR CRONÔMETRO",
                    letterSpacing = 1.sp, fontWeight = FontWeight.Bold
                )
            }

            // Dicas
            NeonCard {
                Column(Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("CONTROLES", fontSize = 11.sp, letterSpacing = 2.sp, color = NeonCyan)
                    HelpRow("1 toque", "Pausar / Continuar")
                    HelpRow("2 toques", "Zerar")
                    HelpRow("Arrastar", "Mover o painel")
                }
            }

            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
fun HelpRow(action: String, desc: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(action, color = NeonBlue, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(desc, color = Color.White.copy(0.7f), fontSize = 13.sp)
    }
}

@Composable
fun NeonCard(
    borderColor: Color = NeonBlue,
    content: @Composable () -> Unit
) {
    Box(
        Modifier.fillMaxWidth()
            .border(1.dp, borderColor.copy(0.5f), RoundedCornerShape(16.dp))
            .background(BgCard, RoundedCornerShape(16.dp))
    ) { content() }
}
