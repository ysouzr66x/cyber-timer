package com.chrononeon.app

import android.app.Application
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.chrononeon.app.service.FloatingService
import com.chrononeon.app.settings.NeonSettings
import com.chrononeon.app.settings.SettingsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class Screen { object Home : Screen(); object Customize : Screen()
    object Config : Screen(); object About : Screen() }

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val repo = SettingsRepository(app)
    val settings: StateFlow<NeonSettings> = repo.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), NeonSettings())

    private val _screen = MutableStateFlow<Screen>(Screen.Home)
    val screen: StateFlow<Screen> = _screen

    fun navigate(s: Screen) { _screen.value = s }

    fun hasOverlayPermission(): Boolean =
        Settings.canDrawOverlays(getApplication())

    fun overlaySettingsIntent(): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)

    fun startFloating() { FloatingService.start(getApplication()) }
    fun stopFloating()  { FloatingService.stop(getApplication()) }

    fun saveSettings(s: NeonSettings) = viewModelScope.launch { repo.save(s) }
}
