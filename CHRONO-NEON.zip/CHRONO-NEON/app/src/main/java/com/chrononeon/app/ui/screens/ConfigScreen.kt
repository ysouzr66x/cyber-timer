package com.chrononeon.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.chrononeon.app.MainViewModel
import com.chrononeon.app.ui.theme.*

@Composable
fun ConfigScreen(vm: MainViewModel) {
    val settings by vm.settings.collectAsState()
    var current by remember(settings) { mutableStateOf(settings) }

    Column(
        Modifier.fillMaxSize().background(BgDeep)
            .padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("CONFIGURAÇÕES", fontSize = 20.sp, fontWeight = FontWeight.Black,
            letterSpacing = 3.sp, color = NeonCyan)

        SectionTitle("COMPORTAMENTO")
        NeonCard {
            Column(Modifier.fillMaxWidth().padding(4.dp)) {
                SettingToggle("Manter ativo em segundo plano", true) {}
                SettingToggle("Salvar posição automaticamente", true) {}
                SettingToggle("Iniciar ao abrir o app", false) {}
            }
        }

        SectionTitle("INTERVALO DO TOQUE DUPLO  —  ${current.doubleTapMs}ms")
        Slider(
            value = current.doubleTapMs.toFloat(),
            onValueChange = { current = current.copy(doubleTapMs = it.toLong()) },
            onValueChangeFinished = { vm.saveSettings(current) },
            valueRange = 150f..600f,
            colors = SliderDefaults.colors(thumbColor = NeonBlue, activeTrackColor = NeonBlue)
        )
        Text("Valor menor = mais rápido • Valor maior = mais tempo para o 2º toque",
            fontSize = 11.sp, color = Color.White.copy(0.5f))

        SectionTitle("PERMISSÕES")
        NeonCard {
            Column(Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val has = vm.hasOverlayPermission()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Sobrepor outros apps", color = Color.White, fontSize = 14.sp)
                    Text(if (has) "✅ Concedida" else "❌ Negada",
                        color = if (has) NeonGreen else NeonRed, fontSize = 13.sp)
                }
            }
        }

        SectionTitle("POSIÇÃO")
        OutlinedButton(
            onClick = { vm.saveSettings(current.copy(savedPosX = -1f, savedPosY = -1f)) },
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, NeonBlue),
            shape = RoundedCornerShape(12.dp)
        ) { Text("RESTAURAR POSIÇÃO PADRÃO", color = NeonBlue, letterSpacing = 1.sp) }

        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxSize().background(BgDeep).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(40.dp))
        Text("CHRONO NEON", fontSize = 28.sp, fontWeight = FontWeight.Black,
            letterSpacing = 4.sp, color = NeonBlue)
        Text("DEVELOPED BY LEONARDO", fontSize = 12.sp, letterSpacing = 2.sp, color = NeonCyan)
        Spacer(Modifier.height(8.dp))
        NeonCard {
            Column(Modifier.fillMaxWidth().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AboutRow("Versão", "1.0.0")
                AboutRow("Desenvolvedor", "Leonardo")
                AboutRow("Android mínimo", "8.0 (API 26)")
                AboutRow("Linguagem", "Kotlin + Compose")
            }
        }
        NeonCard(borderColor = NeonPurple) {
            Column(Modifier.fillMaxWidth().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("PERMISSÕES UTILIZADAS", fontSize = 11.sp, letterSpacing = 2.sp, color = NeonPurple)
                Spacer(Modifier.height(4.dp))
                Text("• SYSTEM_ALERT_WINDOW — Sobreposição de tela",
                    color = Color.White.copy(0.8f), fontSize = 13.sp)
                Text("• FOREGROUND_SERVICE — Execução em segundo plano",
                    color = Color.White.copy(0.8f), fontSize = 13.sp)
                Text("• POST_NOTIFICATIONS — Notificação persistente",
                    color = Color.White.copy(0.8f), fontSize = 13.sp)
                Text("• VIBRATE — Feedback de vibração",
                    color = Color.White.copy(0.8f), fontSize = 13.sp)
            }
        }
        Text("Um cronômetro flutuante moderno, personalizável\ne desenvolvido para praticidade.",
            color = Color.White.copy(0.6f), fontSize = 13.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
fun AboutRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White.copy(0.6f), fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
