package com.chrononeon.app.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.chrononeon.app.MainViewModel
import com.chrononeon.app.settings.NeonSettings
import com.chrononeon.app.ui.theme.*

@Composable
fun CustomizeScreen(vm: MainViewModel) {
    val settings by vm.settings.collectAsState()
    var current by remember(settings) { mutableStateOf(settings) }

    val neonColors = listOf(
        "Azul Neon"   to 0xFF168BFF,
        "Ciano Neon"  to 0xFF00E5FF,
        "Roxo Neon"   to 0xFF8B5CFF,
        "Vermelho"    to 0xFFFF1744,
        "Verde Neon"  to 0xFF00E676,
        "Branco"      to 0xFFFFFFFF,
    )

    val models = listOf("NEON PREMIUM", "CYBER", "MINIMAL", "GLASS", "CUSTOM")

    Column(
        Modifier.fillMaxSize().background(BgDeep)
            .padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(16.dp))
        Text("PERSONALIZAR", fontSize = 20.sp, fontWeight = FontWeight.Black,
            letterSpacing = 3.sp, color = NeonCyan)

        // ── Cores ──────────────────────────────────────────────────────────
        SectionTitle("COR NEON")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            neonColors.forEach { (_, hex) ->
                val c = Color(hex)
                Box(
                    Modifier.size(40.dp)
                        .border(if (current.neonColor == hex) 2.dp else 0.dp,
                            Color.White, RoundedCornerShape(50))
                        .background(c, RoundedCornerShape(50))
                        .clickable {
                            current = current.copy(neonColor = hex)
                            vm.saveSettings(current)
                        }
                )
            }
        }

        // ── Modelo ─────────────────────────────────────────────────────────
        SectionTitle("MODELO")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            models.forEachIndexed { i, name ->
                FilterChip(
                    selected = current.panelModel == i,
                    onClick = { current = current.copy(panelModel = i); vm.saveSettings(current) },
                    label = { Text(name, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonBlue,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // ── Tamanho ────────────────────────────────────────────────────────
        SectionTitle("TAMANHO  —  ${(current.panelSize * 100).toInt()}%")
        Slider(
            value = current.panelSize, onValueChange = { current = current.copy(panelSize = it) },
            onValueChangeFinished = { vm.saveSettings(current) },
            valueRange = 0.6f..1.6f,
            colors = SliderDefaults.colors(thumbColor = NeonBlue, activeTrackColor = NeonBlue)
        )

        // ── Transparência ──────────────────────────────────────────────────
        SectionTitle("TRANSPARÊNCIA  —  ${(current.transparency * 100).toInt()}%")
        Slider(
            value = current.transparency, onValueChange = { current = current.copy(transparency = it) },
            onValueChangeFinished = { vm.saveSettings(current) },
            valueRange = 0.3f..1f,
            colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
        )

        // ── Borda ──────────────────────────────────────────────────────────
        SectionTitle("ESPESSURA DA BORDA  —  ${current.borderWidth.toInt()}dp")
        Slider(
            value = current.borderWidth, onValueChange = { current = current.copy(borderWidth = it) },
            onValueChangeFinished = { vm.saveSettings(current) },
            valueRange = 0f..6f,
            colors = SliderDefaults.colors(thumbColor = NeonPurple, activeTrackColor = NeonPurple)
        )

        // ── Arredondamento ─────────────────────────────────────────────────
        SectionTitle("ARREDONDAMENTO  —  ${current.cornerRadius.toInt()}dp")
        Slider(
            value = current.cornerRadius, onValueChange = { current = current.copy(cornerRadius = it) },
            onValueChangeFinished = { vm.saveSettings(current) },
            valueRange = 0f..32f,
            colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
        )

        // ── Toggles ────────────────────────────────────────────────────────
        SectionTitle("OPÇÕES")
        NeonCard {
            Column(Modifier.fillMaxWidth().padding(4.dp)) {
                SettingToggle("Mostrar milissegundos", current.showMillis) {
                    current = current.copy(showMillis = it); vm.saveSettings(current)
                }
                SettingToggle("Animações", current.animationsEnabled) {
                    current = current.copy(animationsEnabled = it); vm.saveSettings(current)
                }
                SettingToggle("Vibração", current.vibrationEnabled) {
                    current = current.copy(vibrationEnabled = it); vm.saveSettings(current)
                }
                SettingToggle("Sons", current.soundEnabled) {
                    current = current.copy(soundEnabled = it); vm.saveSettings(current)
                }
            }
        }

        // Botão reset
        OutlinedButton(
            onClick = { current = NeonSettings(); vm.saveSettings(current) },
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, NeonRed),
            shape = RoundedCornerShape(12.dp)
        ) { Text("RESTAURAR PADRÃO", color = NeonRed, letterSpacing = 1.sp) }

        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 11.sp, letterSpacing = 2.sp, color = NeonCyan,
        fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
}

@Composable
fun SettingToggle(label: String, checked: Boolean, onChanged: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChanged,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White,
                checkedTrackColor = NeonBlue))
    }
}
