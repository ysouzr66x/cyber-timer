package com.chrononeon.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import com.chrononeon.app.MainActivity
import com.chrononeon.app.R
import com.chrononeon.app.engine.StopwatchEngine
import com.chrononeon.app.engine.TimerState
import com.chrononeon.app.settings.NeonSettings
import com.chrononeon.app.settings.SettingsRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

class FloatingService : Service() {

    companion object {
        const val ACTION_TOGGLE = "TOGGLE"
        const val ACTION_RESET  = "RESET"
        const val ACTION_STOP   = "STOP_SERVICE"
        const val CHANNEL_ID    = "chrono_neon_channel"
        const val NOTIF_ID      = 1

        fun start(ctx: Context) {
            val i = Intent(ctx, FloatingService::class.java)
            ctx.startForegroundService(i)
        }
        fun stop(ctx: Context) {
            val i = Intent(ctx, FloatingService::class.java).apply { action = ACTION_STOP }
            ctx.startService(i)
        }
    }

    private val engine   = StopwatchEngine()
    private lateinit var repo: SettingsRepository
    private lateinit var wm: WindowManager
    private lateinit var floatView: View
    private lateinit var tvTime: TextView
    private lateinit var tvState: TextView
    private var settings: NeonSettings = NeonSettings()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Double-tap detection
    private var lastTapTime = 0L
    private val handler = Handler(Looper.getMainLooper())
    private var pendingSingleTap: Runnable? = null

    // Drag
    private var initX = 0; private var initY = 0
    private var initTouchX = 0f; private var initTouchY = 0f
    private var isDragging = false
    private var dragStartTime = 0L

    override fun onCreate() {
        super.onCreate()
        repo = SettingsRepository(this)
        wm   = getSystemService(WINDOW_SERVICE) as WindowManager
        scope.launch {
            settings = repo.settings.first()
            createNotificationChannel()
            startForeground(NOTIF_ID, buildNotification("00:00:00"))
            buildFloatView()
            startTickLoop()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> engine.toggle()
            ACTION_RESET  -> engine.reset()
            ACTION_STOP   -> { stopSelf(); return START_NOT_STICKY }
        }
        return START_STICKY
    }

    // ── Overlay View ──────────────────────────────────────────────────────────

    private fun buildFloatView() {
        if (!Settings.canDrawOverlays(this)) return

        val sz   = (200 * settings.panelSize).toInt()
        val params = WindowManager.LayoutParams(
            (sz * 1.6).toInt(), sz,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val sp = savedPos()
            x = if (sp.first >= 0) sp.first.toInt() else 100
            y = if (sp.second >= 0) sp.second.toInt() else 300
        }

        val ctx = this
        floatView = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
            alpha = settings.transparency
            background = buildBackground()

            // Título
            addView(TextView(ctx).apply {
                text = "CHRONO NEON"
                textSize = 9f
                setTextColor(neonColor())
                gravity = Gravity.CENTER
                letterSpacing = 0.15f
            })

            // Tempo
            tvTime = TextView(ctx).apply {
                text = "00:00:00"
                textSize = 28f * settings.panelSize
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = Typeface.MONOSPACE
            }
            addView(tvTime)

            // Estado
            tvState = TextView(ctx).apply {
                text = "● PARADO"
                textSize = 9f
                setTextColor(neonColor())
                gravity = Gravity.CENTER
            }
            addView(tvState)
        }

        setupTouchListener(params)
        wm.addView(floatView, params)
    }

    private fun buildBackground(): GradientDrawable {
        val c = settings.neonColor.toInt()
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = settings.cornerRadius * 4
            setColor(Color.argb(230, 11, 11, 18))
            setStroke((settings.borderWidth * 3).toInt(), c)
        }
    }

    private fun neonColor(): Int = settings.neonColor.toInt()

    @Suppress("ClickableViewAccessibility")
    private fun setupTouchListener(params: WindowManager.LayoutParams) {
        floatView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX      = params.x
                    initY      = params.y
                    initTouchX = event.rawX
                    initTouchY = event.rawY
                    isDragging = false
                    dragStartTime = SystemClock.elapsedRealtime()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initTouchX
                    val dy = event.rawY - initTouchY
                    if (!isDragging && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) {
                        isDragging = true
                        pendingSingleTap?.let { handler.removeCallbacks(it) }
                    }
                    if (isDragging) {
                        params.x = (initX + dx).toInt()
                        params.y = (initY + dy).toInt()
                        wm.updateViewLayout(floatView, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isDragging) {
                        scope.launch { repo.savePosition(params.x.toFloat(), params.y.toFloat()) }
                    } else {
                        handleTap()
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ── Double-tap logic ──────────────────────────────────────────────────────

    private fun handleTap() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastTapTime < settings.doubleTapMs) {
            // double tap
            pendingSingleTap?.let { handler.removeCallbacks(it) }
            pendingSingleTap = null
            engine.reset()
            tvState.text = "● PARADO"
        } else {
            // possível single tap — aguarda para ver se vem outro
            lastTapTime = now
            val r = Runnable {
                engine.toggle()
                pendingSingleTap = null
            }
            pendingSingleTap = r
            handler.postDelayed(r, settings.doubleTapMs)
        }
    }

    // ── Tick loop ─────────────────────────────────────────────────────────────

    private fun startTickLoop() {
        scope.launch {
            engine.display.collect { d ->
                val text = d.format(settings.showMillis)
                tvTime.text = text
                tvState.text = when (d.state) {
                    TimerState.RUNNING -> "● CONTANDO"
                    TimerState.PAUSED  -> "⏸ PAUSADO"
                    TimerState.IDLE    -> "● PARADO"
                }
                updateNotification(d.format(false))
            }
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Chrono Neon Timer",
            NotificationManager.IMPORTANCE_LOW).apply {
            description = "Cronômetro flutuante ativo"
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    private fun buildNotification(time: String): Notification {
        val openIntent = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE)
        val toggleIntent = PendingIntent.getService(this, 1,
            Intent(this, FloatingService::class.java).apply { action = ACTION_TOGGLE },
            PendingIntent.FLAG_IMMUTABLE)
        val resetIntent = PendingIntent.getService(this, 2,
            Intent(this, FloatingService::class.java).apply { action = ACTION_RESET },
            PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Chrono Neon  •  $time")
            .setContentText("Toque para abrir")
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "Pausar/Continuar", toggleIntent)
            .addAction(android.R.drawable.ic_menu_revert, "Zerar", resetIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(time: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(time))
    }

    private fun savedPos(): Pair<Float, Float> = Pair(settings.savedPosX, settings.savedPosY)

    override fun onDestroy() {
        scope.cancel()
        engine.reset()
        if (::floatView.isInitialized) {
            runCatching { wm.removeView(floatView) }
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
