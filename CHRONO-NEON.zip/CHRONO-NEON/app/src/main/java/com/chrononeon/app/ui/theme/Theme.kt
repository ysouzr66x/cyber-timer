package com.chrononeon.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NeonBlue   = Color(0xFF168BFF)
val NeonCyan   = Color(0xFF00E5FF)
val NeonPurple = Color(0xFF8B5CFF)
val NeonRed    = Color(0xFFFF1744)
val NeonGreen  = Color(0xFF00E676)
val BgDeep     = Color(0xFF050509)
val BgPanel    = Color(0xFF0B0B12)
val BgCard     = Color(0xFF12121C)

private val DarkColorScheme = darkColorScheme(
    primary         = NeonBlue,
    secondary       = NeonCyan,
    tertiary        = NeonPurple,
    background      = BgDeep,
    surface         = BgPanel,
    onPrimary       = Color.White,
    onSecondary     = Color.White,
    onBackground    = Color.White,
    onSurface       = Color.White,
)

@Composable
fun ChronoNeonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = Typography(),
        content     = content
    )
}
