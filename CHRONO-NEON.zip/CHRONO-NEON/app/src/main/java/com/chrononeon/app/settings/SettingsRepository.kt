package com.chrononeon.app.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore("chrono_neon_prefs")

data class NeonSettings(
    val neonColor: Long         = 0xFF168BFF,  // azul neon padrão
    val panelSize: Float        = 1.0f,         // 0.7=pequeno 1.0=médio 1.4=grande
    val transparency: Float     = 0.92f,
    val brightness: Float       = 1.0f,
    val showMillis: Boolean     = true,
    val animationsEnabled: Boolean = true,
    val soundEnabled: Boolean   = false,
    val vibrationEnabled: Boolean = true,
    val doubleTapMs: Long       = 300L,         // intervalo máximo do double tap
    val panelModel: Int         = 0,            // 0=neon 1=cyber 2=minimal 3=glass 4=custom
    val savedPosX: Float        = -1f,
    val savedPosY: Float        = -1f,
    val cornerRadius: Float     = 16f,
    val borderWidth: Float      = 2f,
)

object Keys {
    val NEON_COLOR      = longPreferencesKey("neon_color")
    val PANEL_SIZE      = floatPreferencesKey("panel_size")
    val TRANSPARENCY    = floatPreferencesKey("transparency")
    val BRIGHTNESS      = floatPreferencesKey("brightness")
    val SHOW_MILLIS     = booleanPreferencesKey("show_millis")
    val ANIMATIONS      = booleanPreferencesKey("animations")
    val SOUND           = booleanPreferencesKey("sound")
    val VIBRATION       = booleanPreferencesKey("vibration")
    val DOUBLE_TAP_MS   = longPreferencesKey("double_tap_ms")
    val PANEL_MODEL     = intPreferencesKey("panel_model")
    val POS_X           = floatPreferencesKey("pos_x")
    val POS_Y           = floatPreferencesKey("pos_y")
    val CORNER_RADIUS   = floatPreferencesKey("corner_radius")
    val BORDER_WIDTH    = floatPreferencesKey("border_width")
}

class SettingsRepository(private val context: Context) {

    val settings: Flow<NeonSettings> = context.dataStore.data.map { p ->
        NeonSettings(
            neonColor         = p[Keys.NEON_COLOR]    ?: 0xFF168BFF,
            panelSize         = p[Keys.PANEL_SIZE]    ?: 1.0f,
            transparency      = p[Keys.TRANSPARENCY]  ?: 0.92f,
            brightness        = p[Keys.BRIGHTNESS]    ?: 1.0f,
            showMillis        = p[Keys.SHOW_MILLIS]   ?: true,
            animationsEnabled = p[Keys.ANIMATIONS]    ?: true,
            soundEnabled      = p[Keys.SOUND]         ?: false,
            vibrationEnabled  = p[Keys.VIBRATION]     ?: true,
            doubleTapMs       = p[Keys.DOUBLE_TAP_MS] ?: 300L,
            panelModel        = p[Keys.PANEL_MODEL]   ?: 0,
            savedPosX         = p[Keys.POS_X]         ?: -1f,
            savedPosY         = p[Keys.POS_Y]         ?: -1f,
            cornerRadius      = p[Keys.CORNER_RADIUS] ?: 16f,
            borderWidth       = p[Keys.BORDER_WIDTH]  ?: 2f,
        )
    }

    suspend fun save(s: NeonSettings) {
        context.dataStore.edit { p ->
            p[Keys.NEON_COLOR]    = s.neonColor
            p[Keys.PANEL_SIZE]    = s.panelSize
            p[Keys.TRANSPARENCY]  = s.transparency
            p[Keys.BRIGHTNESS]    = s.brightness
            p[Keys.SHOW_MILLIS]   = s.showMillis
            p[Keys.ANIMATIONS]    = s.animationsEnabled
            p[Keys.SOUND]         = s.soundEnabled
            p[Keys.VIBRATION]     = s.vibrationEnabled
            p[Keys.DOUBLE_TAP_MS] = s.doubleTapMs
            p[Keys.PANEL_MODEL]   = s.panelModel
            p[Keys.POS_X]         = s.savedPosX
            p[Keys.POS_Y]         = s.savedPosY
            p[Keys.CORNER_RADIUS] = s.cornerRadius
            p[Keys.BORDER_WIDTH]  = s.borderWidth
        }
    }

    suspend fun savePosition(x: Float, y: Float) {
        context.dataStore.edit { p ->
            p[Keys.POS_X] = x
            p[Keys.POS_Y] = y
        }
    }
}
