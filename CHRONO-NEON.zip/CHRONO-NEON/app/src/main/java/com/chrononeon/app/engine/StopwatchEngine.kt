package com.chrononeon.app.engine

import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class TimerState { IDLE, RUNNING, PAUSED }

data class TimerDisplay(
    val hours: Int = 0,
    val minutes: Int = 0,
    val seconds: Int = 0,
    val millis: Int = 0,
    val state: TimerState = TimerState.IDLE,
    val totalMs: Long = 0L
) {
    fun format(showMillis: Boolean): String {
        val base = "%02d:%02d:%02d".format(hours, minutes, seconds)
        return if (showMillis) "$base.%02d".format(millis / 10) else base
    }
}

class StopwatchEngine {

    private val _display = MutableStateFlow(TimerDisplay())
    val display: StateFlow<TimerDisplay> = _display

    private var startElapsed: Long = 0L   // elapsedRealtime quando iniciou/retomou
    private var accumulated: Long = 0L    // ms acumulados antes da pausa atual
    private var state: TimerState = TimerState.IDLE

    private var scope: CoroutineScope? = null
    private var tickJob: Job? = null

    fun start() {
        if (state == TimerState.RUNNING) return
        state = TimerState.RUNNING
        startElapsed = SystemClock.elapsedRealtime()
        scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
        tickJob = scope!!.launch {
            while (isActive) {
                val now  = SystemClock.elapsedRealtime()
                val total = accumulated + (now - startElapsed)
                _display.value = toDisplay(total, state)
                delay(16L) // ~60fps
            }
        }
    }

    fun pause() {
        if (state != TimerState.RUNNING) return
        accumulated += SystemClock.elapsedRealtime() - startElapsed
        state = TimerState.PAUSED
        tickJob?.cancel()
        _display.value = _display.value.copy(state = TimerState.PAUSED)
    }

    fun resume() {
        if (state != TimerState.PAUSED) return
        start()
    }

    fun toggle() {
        when (state) {
            TimerState.IDLE    -> start()
            TimerState.RUNNING -> pause()
            TimerState.PAUSED  -> resume()
        }
    }

    fun reset() {
        tickJob?.cancel()
        scope?.cancel()
        accumulated  = 0L
        startElapsed = 0L
        state = TimerState.IDLE
        _display.value = TimerDisplay(state = TimerState.IDLE)
    }

    fun getState(): TimerState = state

    fun getTotalMs(): Long {
        return if (state == TimerState.RUNNING)
            accumulated + (SystemClock.elapsedRealtime() - startElapsed)
        else accumulated
    }

    // Restaura estado após processo ser morto/retomado
    fun restore(savedMs: Long, savedState: TimerState) {
        accumulated = savedMs
        state = savedState
        if (state == TimerState.RUNNING) {
            start()
        } else {
            _display.value = toDisplay(accumulated, state)
        }
    }

    private fun toDisplay(totalMs: Long, s: TimerState): TimerDisplay {
        val h  = (totalMs / 3_600_000).toInt()
        val m  = ((totalMs % 3_600_000) / 60_000).toInt()
        val sec = ((totalMs % 60_000) / 1_000).toInt()
        val ms = (totalMs % 1_000).toInt()
        return TimerDisplay(h, m, sec, ms, s, totalMs)
    }
}
