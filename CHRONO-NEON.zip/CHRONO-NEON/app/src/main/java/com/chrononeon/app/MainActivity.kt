package com.chrononeon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.*
import com.chrononeon.app.ui.screens.*
import com.chrononeon.app.ui.theme.*

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ChronoNeonTheme {
                ChronoNeonApp(vm)
            }
        }
    }
}

data class NavItem(val label: String, val icon: ImageVector, val tab: Int)

val navItems = listOf(
    NavItem("Início",       Icons.Default.Home,         0),
    NavItem("Personalizar", Icons.Default.Palette,      1),
    NavItem("Config",       Icons.Default.Settings,     2),
    NavItem("Sobre",        Icons.Default.Info,         3),
)

@Composable
fun ChronoNeonApp(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }

    Scaffold(
        containerColor = BgDeep,
        bottomBar = {
            NavigationBar(containerColor = BgPanel, tonalElevation = 0.dp) {
                navItems.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item.tab,
                        onClick  = { tab = item.tab },
                        icon     = { Icon(item.icon, item.label) },
                        label    = { Text(item.label, fontSize = 10.sp) },
                        colors   = NavigationBarItemDefaults.colors(
                            selectedIconColor   = NeonBlue,
                            selectedTextColor   = NeonBlue,
                            unselectedIconColor = Color.White.copy(0.4f),
                            unselectedTextColor = Color.White.copy(0.4f),
                            indicatorColor      = NeonBlue.copy(0.15f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> HomeScreen(vm)
                1 -> CustomizeScreen(vm)
                2 -> ConfigScreen(vm)
                3 -> AboutScreen()
            }
        }
    }
}
