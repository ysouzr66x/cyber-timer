# Tutorial Completo — GitHub → APK pelo Celular
## Sem precisar de computador

---

## O QUE VOCÊ VAI PRECISAR

- Celular Android com internet
- Conta no GitHub (gratuita)
- ZArchiver (Play Store — gratuito)
- Chrome ou qualquer navegador
- Os arquivos do projeto (zip)

---

## PARTE 1 — CRIAR CONTA NO GITHUB

1. Abre o Chrome
2. Acessa: **https://github.com**
3. Toca em **Sign up**
4. Preenche:
   - Username (nome de usuário — sem espaços)
   - Email
   - Senha
5. Toca em **Continue**
6. Resolve o captcha
7. Escolhe o plano **Free**
8. Confirma o email (abre o email e clica no link)

---

## PARTE 2 — CRIAR O REPOSITÓRIO

1. Loga no GitHub
2. Toca no **+** no canto superior direito
3. Toca em **New repository**
4. Preenche:
   - **Repository name:** `chrono-neon`
   - **Description:** Chrono Neon — Floating Timer
   - Marca **Public**
   - Marca **Add a README file**
5. Toca em **Create repository**

---

## PARTE 3 — EXTRAIR O ZIP DO PROJETO

1. Abre o **ZArchiver**
2. Navega até onde está o arquivo `CHRONO-NEON.zip`
   - Geralmente em Downloads
3. Toca no arquivo zip
4. Toca em **Extrair aqui** ou **Extract here**
5. Aguarda extrair
6. Vai aparecer a pasta `CHRONO-NEON` com todos os arquivos

---

## PARTE 4 — ENVIAR OS ARQUIVOS PARA O GITHUB

O GitHub pelo celular não aceita upload de pastas inteiras de uma vez.
Vamos enviar arquivo por arquivo nas pastas certas.

### 4.1 — Criar a estrutura de pastas no GitHub

No repositório que criou:

1. Toca em **Add file → Create new file**
2. No campo do nome do arquivo digita:
   ```
   app/src/main/AndroidManifest.xml
   ```
3. Copia o conteúdo do arquivo `AndroidManifest.xml` que está na pasta extraída
4. Cola no editor
5. Toca em **Commit changes**
6. Toca em **Commit changes** de novo

Repete esse processo para cada arquivo do projeto.

### 4.2 — Ordem de envio dos arquivos

Envia nessa ordem:

```
1. settings.gradle.kts          (raiz)
2. build.gradle.kts             (raiz)
3. gradle/libs.versions.toml
4. app/build.gradle.kts
5. app/src/main/AndroidManifest.xml
6. app/src/main/res/values/colors.xml
7. app/src/main/res/values/strings.xml
8. app/src/main/res/values/themes.xml
9. Todos os arquivos .kt da pasta java/
10. .github/workflows/build.yml  ← MAIS IMPORTANTE
```

### 4.3 — Dica para ir mais rápido

Para cada arquivo:
1. Abre o arquivo no ZArchiver (toca → Abrir com → Editor de texto)
2. Seleciona tudo (segura → Selecionar tudo)
3. Copia
4. No GitHub, cria o arquivo no caminho certo e cola

---

## PARTE 5 — CRIAR O WORKFLOW DE COMPILAÇÃO

Esse é o arquivo mais importante. Ele instrui o GitHub a compilar o APK.

1. No repositório, toca em **Add file → Create new file**
2. No nome digita exatamente:
   ```
   .github/workflows/build.yml
   ```
3. Cola o conteúdo abaixo:

```yaml
name: Build APK

on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout código
        uses: actions/checkout@v4

      - name: Configura Java 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Permissão no gradlew
        run: chmod +x gradlew

      - name: Compila APK Debug
        run: ./gradlew assembleDebug

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: ChronoNeon-APK
          path: app/build/outputs/apk/debug/app-debug.apk
          retention-days: 7
```

4. Toca em **Commit changes**

---

## PARTE 6 — EXECUTAR A COMPILAÇÃO

### Opção A — Automático (já executa ao enviar arquivos)
Toda vez que você fizer commit, o GitHub Actions executa automaticamente.

### Opção B — Manual
1. No repositório, toca na aba **Actions**
2. No menu esquerdo toca em **Build APK**
3. Toca em **Run workflow**
4. Toca em **Run workflow** de novo (botão verde)
5. Aguarda aparecer o círculo girando (compilando)

---

## PARTE 7 — ACOMPANHAR A COMPILAÇÃO

1. Toca na aba **Actions**
2. Toca no workflow em execução (círculo amarelo girando)
3. Toca em **build** para ver os detalhes
4. Vai aparecendo o log em tempo real

**Quanto tempo demora:**
- Primeira vez: 5 a 10 minutos
- Próximas vezes: 3 a 5 minutos (usa cache)

**Símbolos:**
- 🟡 Círculo girando = compilando
- ✅ Check verde = compilou com sucesso
- ❌ X vermelho = deu erro (veja o log)

---

## PARTE 8 — BAIXAR O APK

Quando aparecer o ✅ verde:

1. Toca no workflow concluído
2. Rola a página até o final
3. Procura a seção **Artifacts**
4. Toca em **ChronoNeon-APK**
5. O download começa automaticamente
6. O arquivo baixado é um ZIP chamado `ChronoNeon-APK.zip`

---

## PARTE 9 — INSTALAR O APK

1. Abre o **ZArchiver**
2. Navega até Downloads
3. Toca em `ChronoNeon-APK.zip`
4. Toca em **Extrair aqui**
5. Vai aparecer o arquivo `app-debug.apk`
6. Toca no arquivo `.apk`
7. Toca em **Instalar**

Se aparecer aviso de segurança:
- Toca em **Configurações**
- Ativa **Permitir desta fonte**
- Volta e instala

---

## SE DER ERRO NA COMPILAÇÃO

### Como ler o erro:
1. Toca na aba **Actions**
2. Toca no workflow com ❌
3. Toca em **build**
4. Procura a linha vermelha com o erro

### Erros comuns:

| Erro | Solução |
|---|---|
| `gradlew: Permission denied` | O build.yml já tem `chmod +x gradlew` — verifica se o arquivo gradlew está no repositório |
| `SDK location not found` | Adiciona o arquivo `local.properties` com `sdk.dir=/usr/local/lib/android/sdk` |
| `Could not resolve` | Problema de dependência — verifica o `libs.versions.toml` |
| `Manifest merger failed` | Verifica o `AndroidManifest.xml` |
| `Kotlin compilation error` | Erro no código .kt — vê qual arquivo e linha |

---

## PARTE 10 — ATUALIZAR O PROJETO

Quando quiser mudar algum arquivo:

1. No repositório, navega até o arquivo
2. Toca no ícone de **lápis** (editar)
3. Faz a alteração
4. Toca em **Commit changes**
5. O GitHub Actions compila automaticamente de novo

---

## RESUMO RÁPIDO

```
1. Cria conta no GitHub
2. Cria repositório "chrono-neon"
3. Extrai o ZIP com ZArchiver
4. Envia os arquivos um por um pro GitHub
5. Cria .github/workflows/build.yml
6. Actions → Run workflow
7. Aguarda ✅ verde (5-10 min)
8. Baixa o ZIP dos Artifacts
9. Extrai com ZArchiver → instala o .apk
```

---

## DICAS IMPORTANTES

- **Não fecha o Chrome** durante o upload dos arquivos
- **Respeita os caminhos** — o arquivo precisa estar na pasta certa
- **O gradlew** precisa estar na raiz do projeto (não dentro de app/)
- **Primeira compilação** é sempre mais lenta
- **APK debug** funciona normalmente para instalar e testar
- Se quiser APK **release** (para publicar), precisa de uma keystore — debug já serve para uso pessoal
